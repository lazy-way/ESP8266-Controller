package com.intelliqcell.esp8266controller;

import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, JoystickView.JoystickListener {
    ImageButton brake, accelerate;
    ToggleButton clock, anticlock;
    JoystickView joyStick;
    Button stopButton;
    TextView speedView, sliderView;
    int x, speedValue;
    private boolean mBrake=false, mAccelerate=false;
    private Handler repeatUpdateHandler = new Handler();
    String s, v1, v2;
    String IP = "192.168.4.1";
    int PORT = 1337;
    Socket client;
    OutputStreamWriter writer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initializing variables...
        brake = findViewById(R.id.brake);
        accelerate = findViewById(R.id.accelerate);
        joyStick = findViewById(R.id.joyStick);
        clock = findViewById(R.id.toggleRight);
        anticlock = findViewById(R.id.toggleLeft);
        stopButton = findViewById(R.id.stopButton);
        speedValue = 0;
        speedView = findViewById(R.id.speedView);
        sliderView = findViewById(R.id.sliderView);
        x = 0;

        //starting socket...
        new Thread() {
            @Override
            public void run() {
                try {
                    client = new Socket(IP, PORT);
                    writer = new OutputStreamWriter(client.getOutputStream(),"ISO-8859-1");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();

        //setting toggle button...
        clock.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    setSendingData("x");
                    anticlock.setChecked(false);
                    new SendData().execute();
                } else{
                    setSendingData("xo");
                    new SendData().execute();
                }
            }
        });

        anticlock.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    setSendingData("y");
                    clock.setChecked(false);
                    new SendData().execute();
                } else{
                    setSendingData("yo");
                    new SendData().execute();
                }
            }
        });

        //setting onClick methods for button...
        brake.setOnClickListener(this);
        accelerate.setOnClickListener(this);
        stopButton.setOnClickListener(this);

        //setting onLongClickListener...
        brake.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                mBrake = true;
                repeatUpdateHandler.post(new Updater());
                return false;
            }
        });

        accelerate.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                mAccelerate = true;
                repeatUpdateHandler.post(new Updater());
                return false;
            }
        });

        //method to stop increment or decrement when touch is lifted...
        brake.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if((motionEvent.getAction()==MotionEvent.ACTION_CANCEL || motionEvent.getAction()==MotionEvent.ACTION_UP) && mBrake){
                    mBrake = false;
                }
                return false;
            }
        });

        accelerate.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if((motionEvent.getAction()==MotionEvent.ACTION_CANCEL || motionEvent.getAction()==MotionEvent.ACTION_UP) && mAccelerate){
                    mAccelerate = false;
                }
                return false;
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.brake:
                //code for brake button here...
                if(speedValue > -1024){
                    speedValue-=204;
                    if(speedValue < 0){
                        setSendingData("r", Integer.toString(-1*speedValue), Integer.toString(-1*speedValue));
                    } else{
                        setSendingData("f", Integer.toString(speedValue), Integer.toString(speedValue));
                    }
                    speedView.setText(Integer.toString(speedValue));
                    new SendData().execute();
                }
                break;

            case R.id.accelerate:
                //code for accelerate button here...
                if(speedValue < 1024){
                    speedValue+=204;
                    if(speedValue < 0){
                        setSendingData("r", Integer.toString(-1*speedValue), Integer.toString(-1*speedValue));
                    } else
                        setSendingData("f", Integer.toString(speedValue), Integer.toString(speedValue));
                    speedView.setText(Integer.toString(speedValue));
                    new SendData().execute();
                }
                break;

            case R.id.stopButton:
                speedValue = 0;
                speedView.setText("0");
                setSendingData("f", "0", "0");
                new SendData().execute();
                break;
        }
    }

    @Override
    public void onJoystickMoved(float xPercent, float yPercent, int id) {
        x = (int) (1023 * xPercent);
        speedValue = 0;
        speedView.setText("0");
        if(x == 0){
            setSendingData("f", "0", "0");
            sliderView.setText("L: 0 and R: 0");
        }
        else if(x < 0){
            setSendingData("f", Integer.toString(0), Integer.toString(-1*x));
            sliderView.setText("L: 0 and R: " + Integer.toString(-1*x));
        }
        else{
            setSendingData("f", Integer.toString(x), Integer.toString(0));
            sliderView.setText("L: " + Integer.toString(x) + " and R: 0");
        }
        new SendData().execute();
    }

    class Updater implements Runnable{
        @Override
        public void run() {
            if(mBrake){
                if(speedValue > -1024){
                    speedValue-=204;
                    if(speedValue < 0){
                        setSendingData("r", Integer.toString(-1*speedValue), Integer.toString(-1*speedValue));
                    } else{
                        setSendingData("f", Integer.toString(speedValue), Integer.toString(speedValue));
                    }
                    speedView.setText(Integer.toString(speedValue));
                    new SendData().execute();

                    //method to feed this value to server here...

                    repeatUpdateHandler.postDelayed(new Updater(), 50);
                }
            } else if(mAccelerate){
                if(speedValue < 1024){
                    speedValue+=204;
                    if(speedValue < 0){
                        setSendingData("r", Integer.toString(-1*speedValue), Integer.toString(-1*speedValue));
                    } else{
                        setSendingData("f", Integer.toString(speedValue), Integer.toString(speedValue));
                    }
                    speedView.setText(Integer.toString(speedValue));
                    new SendData().execute();

                    repeatUpdateHandler.postDelayed(new Updater(), 50);
                }
            }
        }
    }

    class SendData extends AsyncTask{

        @Override
        protected Object doInBackground(Object[] objects) {
            //commandView.setText(command + "z");
            try {
                writer.write(s + v1 + v2 + "z");
                writer.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public void setSendingData(String s, String v1, String v2){
        if(Integer.parseInt(v1) < 10)
            v1 = "000" + v1;
        else if(Integer.parseInt(v1) < 100)
            v1 = "00" + v1;
        else if(Integer.parseInt(v1) < 1000)
            v1 = "0" + v1;

        if(Integer.parseInt(v2)<10)
            v2 = "000" + v2;
        else if(Integer.parseInt(v2)<100)
            v2 = "00" + v2;
        else if(Integer.parseInt(v2) < 1000)
            v2 = "0" + v2;

        this.s = s;
        this.v1 = v1;
        this.v2 = v2;
    }

    public void setSendingData(String s){
        this.s = s;
        this.v1 = "";
        this.v2 = "";
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            writer.close();
            client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
